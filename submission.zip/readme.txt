Link to static website
https://hub.labs.coursera.org/connect/sharedqnyobstw?forceRefresh=false&path=%2F&isLabVersioning=true