# lon-uni-gs-wd-task-p2

Tim has Kindly Completed some [Wireframe](https://www.figma.com/team_invite/redeem/Os54PrfILV1iaovmKu4LYP) for us to work off.

Notion Document - [Here](https://noxos.notion.site/Team-Project-ec4189d17d214a2baa56349787d082c6?pvs=4) Created to quickly write up some thoughts and partially manage the project. 

